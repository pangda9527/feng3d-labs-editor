
class NewScript extends feng3d.Script {

    /** 
     * 测试属性 
     */
    @feng3d.serialize
    @feng3d.oav()
    radius = 2;

    /**
     * 初始化时调用
     */
    init() {
        feng3d.shortcut.addShortCuts([{ key: "1", command: "play" }, { key: "2", command: "stop" }]);
        feng3d.shortcut.on("play", this.onPlay, this);
        feng3d.shortcut.on("stop", this.onStop, this);
        alert("按1键播放声音，按2键停止播放声音");
    }

    private onPlay() {
        var audioSource = this.gameObject.getComponent(feng3d.AudioSource);
        if (audioSource) {
            audioSource.play();
        }
    }

    private onStop() {
        var audioSource = this.gameObject.getComponent(feng3d.AudioSource);
        if (audioSource) {
            audioSource.stop();
        }
    }

    /**
     * 更新
     */
    update() {
        var angle = ((Date.now() / 1000) % 60 * 3) * Math.PI / 30;
        this.transform.x = Math.sin(angle) * this.radius;
        this.transform.z = Math.cos(angle) * this.radius;
    }

    /**
     * 销毁时调用
     */
    dispose() {

    }
}