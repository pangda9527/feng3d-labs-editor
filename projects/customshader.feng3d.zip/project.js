var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var NewShaderUniforms = /** @class */ (function () {
    function NewShaderUniforms() {
        /**
         * 颜色
         */
        this.u_color = new feng3d.Color4();
    }
    __decorate([
        feng3d.serialize,
        feng3d.oav()
    ], NewShaderUniforms.prototype, "u_color", void 0);
    return NewShaderUniforms;
}());
feng3d.shaderConfig.shaders["NewShader"] = {
    cls: NewShaderUniforms,
    vertex: "\n    \n    attribute vec3 a_position;\n    \n    uniform mat4 u_modelMatrix;\n    uniform mat4 u_viewProjection;\n    \n    void main() {\n    \n        vec4 globalPosition = u_modelMatrix * vec4(a_position, 1.0);\n        gl_Position = u_viewProjection * globalPosition;\n    }",
    fragment: "\n    \n    precision mediump float;\n    \n    uniform vec4 u_color;\n    \n    void main() {\n        \n        gl_FragColor = u_color;\n    }\n    ",
};
//# sourceMappingURL=project.js.map