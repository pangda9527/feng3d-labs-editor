
class NewScript extends feng3d.Script {

    /** 
     * 测试属性 
     */
    @feng3d.serialize
    @feng3d.oav()
    t_attr = 1;

    /**
     * 初始化时调用
     */
    init() {

    }

    /**
     * 更新
     */
    update() {
        this.transform.ry += this.t_attr;
    }

    /**
     * 销毁时调用
     */
    dispose() {

    }
}